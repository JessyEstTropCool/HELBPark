public abstract class DiscountType 
{
    //classe de base pour toutes les réductions

    public abstract double applyDiscount(double initialPrice, Vehicle vehicle);
}
