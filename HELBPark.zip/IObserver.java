public interface IObserver 
{
    //classe de base pour tout les observer de ParkSpaces

    void update(Object observable);
}
