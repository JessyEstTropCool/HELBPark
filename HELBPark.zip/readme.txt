To run, execute the following command :

bash run.sh