import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.text.TextAlignment;
import javafx.geometry.Pos;
import javafx.geometry.Insets;

/*A simple Window with a Button in the center*/
public class MoneyGiver extends Application {

    Label lTitre;
    Button button;
    VBox vbDebts;

    public static void main(String[] args){
        launch(args);
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception{
        //In javafX a Stage (Window) contains a Scene(Layout+components)
        primaryStage.setTitle("Money Giver");

        VBox layout = new VBox();

        lTitre = new Label("You have 0 monies");
        lTitre.setPrefWidth(300);
        lTitre.setPrefHeight(25);
        lTitre.setAlignment(Pos.CENTER);

        vbDebts = new VBox();
        vbDebts.setPadding(new Insets(10, 10, 10, 10));
        vbDebts.setPrefWidth(300);
        
        button = new Button();
        button.setText("Nouvelle dépense");
        button.setOnAction(e -> {
            vbDebts.getChildren().add(new Label("Bonjour !"));
        });

        layout.getChildren().add(lTitre);
        layout.getChildren().add(vbDebts);
        layout.getChildren().add(button);
        
        Scene scene = new Scene(layout, 300, 250);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}

